export default [
  {
    id: 1,
    city: "San Salvador de Jujuy",
    lat: -24.18,
    lon: -65.29,
  },
  {
    id: 2,
    city: "Buenos Aires",
    lat: -34.60,
    lon: -58.38,
  },
  {
    id: 3,
    city: "Londres",
    lat: 51.49,
    lon: -0.12,
  },
  {
    id: 4,
    city: "Moscu",
    lat: 55.76,
    lon: 37.61,
  },
  {
    id: 5,
    city: "El Cairo",
    lat: 30.04,
    lon: 31.23,
  },
  {
    id: 6,
    city: "Sidney",
    lat: -33.86,
    lon: 151.20,
  },
];
